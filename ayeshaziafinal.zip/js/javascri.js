
// portfolio images popups

function img1(){
    window.open("file:///E:/Ayesha%20Zia/images/col11.jpeg" , "bride in white")
}

function img2(){
    window.open("file:///E:/Ayesha%20Zia/images/col12.jpeg")
}

function img3(){
    window.open("file:///E:/Ayesha%20Zia/images/col13.jpeg")
}

function img4(){
    window.open("file:///E:/Ayesha%20Zia/images/col14.jpeg")
}

function img5(){
    window.open("file:///E:/Ayesha%20Zia/images/col15.jpeg")
}
  var b = document.getElementsByTagName("a")
  console.log(b)